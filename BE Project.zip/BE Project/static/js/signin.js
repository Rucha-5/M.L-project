document.addEventListener("DOMContentLoaded", function() {
    const sign_in_btn = document.querySelector("#sign-in-btn");
    const sign_up_btn = document.querySelector("#sign-up-btn");
    const container = document.querySelector(".container");

    sign_up_btn.addEventListener("click", () => {
        container.classList.add("sign-up-mode");
    });

    sign_in_btn.addEventListener("click", () => {
        container.classList.remove("sign-up-mode");

        // Redirect to ash.html after successful sign-in
        sign_in_success_redirect();
        console.log("Login button clicked");

    });

    function sign_in_success_redirect() {
        // Here you can add your sign-in logic
        // Once sign-in is successful, redirect to ash.html
        window.location.href = 'ash.html';
    }
});

