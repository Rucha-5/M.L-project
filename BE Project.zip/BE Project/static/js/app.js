document.addEventListener('DOMContentLoaded', function() {
    var inputFields = document.querySelectorAll('.inputField');
    var currentFieldIndex = 0;
    var nextButton = document.getElementById('nextButton');

    // Show the first input field
    inputFields[currentFieldIndex].classList.remove('hidden');

    nextButton.addEventListener('click', function() {
        // Hide the current input field
        inputFields[currentFieldIndex].classList.add('hidden');

        // Move to the next input field
        currentFieldIndex++;

        // If there are more input fields, show the next one
        if (currentFieldIndex < inputFields.length) {
            inputFields[currentFieldIndex].classList.remove('hidden');
        } else {
            // If all input fields have been shown, trigger the comparison
            comparePrices();
        }
    });

    function comparePrices() {
        var brand = document.getElementById('brand').value;
        var model = document.getElementById('model').value;
        var color = document.getElementById('color').value;
        var rating = document.getElementById('rating').value;

        // Send a request to the backend with the input parameters
        // Update the 'output' div with the result received from the backend
        // Example:
        // document.getElementById('output').innerText = `Fetching prices for ${brand} ${model} (${color}) with rating ${rating}...`;
    }
});