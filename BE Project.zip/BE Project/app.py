from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.impute import SimpleImputer

app = Flask(__name__, static_url_path='/static')

# Load datasets
flipkart_data = pd.read_csv('static/Flipkart_Mobiles.csv')
amazon_data = pd.read_csv('static/Amazon_Mobiles.csv')
indiamart_data = pd.read_csv('static/Indiamart_Mobiles.csv')
snapdeal_data = pd.read_csv('static/Snapdeal_Mobiles.csv')

# Conversion function
def convert(price):
    if price:
        cleaned_price = ''.join(filter(str.isdigit, str(price)))
        return int(cleaned_price) if cleaned_price else 0
    return 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ash.html')
def serve_ash_html():
    return render_template('ash.html')

@app.route('/search', methods=['POST'])
def search():
    brand_input = request.form['brand'].strip()
    model_input = request.form['model'].strip()
    color_input = request.form['color'].strip()
    rating_input = float(request.form['rating'])
    print(f"Received inputs: {brand_input}, {model_input}, {color_input}, {rating_input}")

    # Your search logic here
    return redirect(url_for('predict'))

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        brand_input = request.form['brand'].strip()
        model_input = request.form['model'].strip()
        color_input = request.form['color'].strip()
        rating_input = float(request.form['rating'])

        def train_model(data, rating_col, price_col):
            X = data[[rating_col]].values
            y = data[price_col].values
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            # Handle missing values with SimpleImputer
            imputer = SimpleImputer(strategy='mean')
            X_train = imputer.fit_transform(X_train)
            X_test = imputer.transform(X_test)

            model = LinearRegression()
            model.fit(X_train, y_train)
            return model.predict([[rating_input]])

        def get_price_and_rating(product_data, rating_col, price_col):
            product = product_data[
                (product_data['Brand'].str.strip().str.upper() == brand_input.upper()) &
                (product_data['Model'].str.strip().str.upper() == model_input.upper()) &
                (product_data['Color'].str.strip().str.upper() == color_input.upper()) &
                (product_data['Rating'] == rating_input)
            ]
            price = product[price_col].values[0] if not product.empty else None
            rating = train_model(product_data, rating_col, price_col) if not product.empty else None
            return convert(price), rating[0] if rating is not None else None

        flipkart_price, predicted_rating_flipkart = get_price_and_rating(flipkart_data, 'Rating', 'Original Price')
        amazon_price, predicted_rating_amazon = get_price_and_rating(amazon_data, 'Rating', 'Original Price')
        indiamart_price, predicted_rating_indiamart = get_price_and_rating(indiamart_data, 'Rating', 'Original Price')
        snapdeal_price, predicted_rating_snapdeal = get_price_and_rating(snapdeal_data, 'Rating', 'Original Price')

        # Compare prices to suggest which option is better
        def suggest_best_option(prices):
            best_price = min(prices)
            platforms = ['Flipkart', 'Amazon', 'Indiamart', 'Snapdeal']
            best_platform = platforms[prices.index(best_price)]
            return f"Buy from {best_platform}, Price is Less."

        prices = [flipkart_price, amazon_price, indiamart_price, snapdeal_price]
        suggestion = suggest_best_option(prices)

        search_results = [
            {'online_site': 'Flipkart', 'brand': brand_input, 'model': model_input, 'color': color_input,
             'original_price': flipkart_price,
             'predicted_rating_flipkart': predicted_rating_flipkart},
            {'online_site': 'Amazon', 'brand': brand_input, 'model': model_input, 'color': color_input,
             'original_price': amazon_price,
             'predicted_rating_amazon': predicted_rating_amazon},
            {'online_site': 'Indiamart', 'brand': brand_input, 'model': model_input, 'color': color_input,
             'original_price': indiamart_price,
             'predicted_rating_Indiamart': predicted_rating_indiamart},
            {'online_site': 'Snapdeal', 'brand': brand_input, 'model': model_input, 'color': color_input,
             'original_price': snapdeal_price,
             'predicted_rating_snapdeal': predicted_rating_snapdeal}
        ]

        # Debug prints
        print("Search Results:", search_results)
        print("Suggestion:", suggestion)

        return render_template('result.html', search_results=search_results, suggestion=suggestion)

    else:
        return render_template('result.html')


if __name__ == '__main__':
    app.run(debug=True)
